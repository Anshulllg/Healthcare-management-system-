import java.util.ArrayList;
import java.util.Scanner;

public class pic {

    private int[][] mat;
    private int row;
    private int col;

    static Scanner sc = new Scanner(System.in);

    public pic (int row, int col, int[][] mat) {
        this.row = row;
        this.col = col;
        this.mat = mat;

    }

    public int getCol() {
        return col;
    }

    public int getRow() {
        return row;
    }

    public int[][] getMat() {
        return mat;
    }

    public void change(int rn,int cn,int nno){
        this.mat[rn][cn] =nno;
    }

    public void viewm() {
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                System.out.print(mat[i][j] + "  ");
            }
            System.out.println();
        }
    }

    public void neg(){
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                mat[i][j]=255-mat[i][j];
            }
        }
        viewm();
    }


}
