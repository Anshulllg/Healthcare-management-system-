import java.util.ArrayList;
import java.util.Scanner;

public class main {

    static Scanner sc = new Scanner(System.in);
    static ArrayList<pic> pdata = new ArrayList<>();

    public static void main(String[] args) {
        int check = 1;
        do {
            System.out.println("Welcome to Photomaker");
            System.out.println("1. Create picture\n" + "2. Negative of picture \n" + "3. Update picture/n"+"4. Display\n"+ "5. Exit");

            int n = sc.nextInt();
            sc.nextLine();
            switch (n) {
                case 1:
                    System.out.println("Enter 1 for greyscale image and 2 for RGB:");
                    int nn=sc.nextInt();
                    if(nn==1){
                        System.out.println("rows");
                        int row=sc.nextInt();
                        System.out.println("columns");
                        int col=sc.nextInt();
                        int [][] mat =new int [row][col];
                        for(int i=0;i<row;i++) {
                            System.out.println("Enter the pixel of row " + i);

                            for (int j = 0; j <col; j++) {
                                int input=sc.nextInt();
                                if( input>=1 && input<=255){
                                    mat[i][j] = sc.nextInt();
                                }
                                else{
                                    System.out.println("bit value of of range 0-255, enter again");
                                    j--;
                                }

                            }
                        }
                        pic a=new pic(row,col,mat);
                        pdata.add(a);
                    }
                    else{
                        System.out.println("rows");
                        int row=sc.nextInt();
                        System.out.println("columns");
                        int col=sc.nextInt();
                        int [][] mat =new int [row][col];
                        for(int i=0;i<row;i++) {
                            System.out.println("Enter the pixel of row " + i);
                            for (int j = 0; j <col; j++) {
                                int input=sc.nextInt();
                                if( input>=1 && input<=255){
                                    mat[i][j] = sc.nextInt();
                                }
                                else{
                                    System.out.println("bit value of of range 0-255, enter again");
                                    j--;
                                }
                            }
                        }
                        pic a=new pic(row,col,mat);
                        pdata.add(a);

                    }


                    break;
                case 2:

                    break;
                case 3:

                    for(int i=0;i< pdata.size();i++){
                        System.out.print("("+i+") " );
                        pdata.get(i).viewm();
                    }
                    System.out.println("Enter the id to update that matrix");
                    int id=sc.nextInt();

                    System.out.print("Enter the new number : ");
                    int nno = sc.nextInt();
                    System.out.print("Row where you want to update : ");
                    int rn = sc.nextInt();
                    System.out.print("Col where you want to update : ");
                    int cn = sc.nextInt();
                    pdata.get(id).change(rn,cn,nno);

                    break;
                case 4:
                    System.out.println("All matrices are : ");
                    for(int i=0;i< pdata.size();i++){
                        System.out.print("("+i+") " );
                        pdata.get(i).viewm();
                    }
                    break;
                case 5:
                    check=0;
                    break;
            }

        } while (check == 1);


    }


}
