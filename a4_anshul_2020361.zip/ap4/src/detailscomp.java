//public class detailscomp implements comparator<lib>{
//    @Override
//    public int compareTo(lib other) {
//        if(this.name.compareTo(other.name))
//        return ;
//    }
//}
