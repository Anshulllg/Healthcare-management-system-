//public class namecomp implements comparator <lib>{
//    @Override
//    public int compare(Object first, Object second) {
//        return 0;
//    }
//}
