public class slots {
    private int k;
    private int r;


    slots( int k, int r){
        this.k=k;
        this.r=r;
    }

    public int getK() {
        return k;
    }

    public int getR() {
        return r;
    }
}
