import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class lib  <name, isbn, barcode>{

        name obj1;
        isbn obj2;
        barcode obj3;

        lib(name obj1, isbn obj2, barcode obj3)
        {
            this.obj1 = obj1;
            this.obj2 = obj2;
            this.obj3 = obj3;
        }



    private String name ;
    private String isbn;
    private String barcode;

    static Scanner sc = new Scanner(System.in);


    lib(String name,String isbn,String barcode){
        this.name=name;
        this.isbn=isbn;
        this.barcode=barcode;
    }

    public String getName() {
        return name;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getBarcode() {
        return barcode;
    }

//    public int compareTo()

//    @Override
//    public int compareTo(lib other) {
//        if(this.name.compareTo(other.name)) {
//            return name.compareTo(other.name);
//        }else if(this.isbn.compareTo(other.isbn)){
//            return isbn.compareTo(other.isbn);
//        }else{
//            return isbn.compareTo(other.isbn);
//        }
//    }

//    public void display()
//    {
//        int k=0;
//        for(int i=0;i<getR();i++)
//        {
//            System.out.println("Rack number "+i);
//            for(int j=0;j<this.slots;j++)
//            {
//                .get(k).display();
//                System.out.println(" Slot "+(j+1));
//                k+=1;
//            }
//        }
//    }



//    void bubsort(ArrayList bdata) {
//        int n=bdata.size();
//        for (int j = 0; j < n - 1; j++)
//        {
//            for (int i = j + 1; i < n; i++)
//            {
//                if (bdata.get(j).name.compareTo(bdata.get(i).name)!=0)
//                {
//                    String temp = bdata.get(j).name;
//                    bdata.get(j).name = bdata.get(i).name;
//                    bdata.get(i).name = temp;
//                }
//                else{
//                    if (bdata.get(j).isbn.compareTo(bdata.get(i).isbn)!=0){
//                        String temp = bdata.get(j).isbn;
//                        bdata.get(j).isbn = bdata.get(i).isbn;
//                        bdata.get(i).isbn = temp;
//                    }
//                    else{
//                        if (bdata.get(j).barcode.compareTo(bdata.get(i).barcode)!=0){
//                            String temp = bdata.get(j).barcode;
//                            bdata.get(j).barcode = bdata.get(i).barcode;
//                            bdata.get(i).barcode = temp;
//                        }
//
//                    }
//
//                }
//            }
//        }
//    }
}
