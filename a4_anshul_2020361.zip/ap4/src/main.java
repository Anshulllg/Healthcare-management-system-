import java.awt.print.Book;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class main {

    static Scanner sc = new Scanner(System.in);
    static ArrayList<lib> bdata = new ArrayList<>();
    public static void main(String[] args) {

        int check = 1;
        do {
            System.out.println("Welcome to Library");
            System.out.println("1. Add books\n" + "2. View library \n" + "3. Exit");

            int n = sc.nextInt();
            sc.nextLine();
            switch (n) {
                case 1:
                    System.out.println("Enter no of books:");
                    int k= sc.nextInt();
                    System.out.println("Enter no of racks:");
                    int r= sc.nextInt();
                    System.out.println("No of slots available = "+k/r);
                    sc.nextLine();
                    for(int i=0; i<k; i++){
                        System.out.println("Enter name of  the book:");
                        String name= sc.nextLine();
                        sc.nextLine();
                        System.out.println("Enter ISBN of  the book:");
                        int isbn= sc.nextInt();
                        System.out.println("Enter barcode of  the book:");
                        int barcode= sc.nextInt();
                        lib <String, Integer, Integer> obj = new lib<String, Integer,Integer>(name, isbn, barcode);

                        lib book= new lib(name, isbn, barcode);
                        bdata.add(book);
                    }
//                    int n=bdata.size();
                    for (int j = 0; j < k - 1; j++)
                    {
                        for (int i = j + 1; i < k; i++)
                        {
                            if (bdata.get(j).getName().compareTo(bdata.get(i).getName())>0)
                            {
                                lib temp = bdata.get(j);
                                bdata.set(j, bdata.get(i));
                                bdata.set(i, temp);
                            }
                            else{
                                if ((bdata.get(j).getIsbn()).equals((bdata.get(i).getIsbn()))){
                                    lib temp = bdata.get(j);
                                    bdata.set(j, bdata.get(i));
                                    bdata.set(i, temp);
                                }
                                else{
                                    if ((bdata.get(j).getBarcode()).equals((bdata.get(i).getBarcode()))){
                                        lib temp = bdata.get(j);
                                        bdata.set(j, bdata.get(i));
                                        bdata.set(i, temp);
                                    }

                                }

                            }
                        }
                    }

                    break;

                case 2:
                    for(int i=0; i<5; i++) {
                        System.out.print(bdata.get(i).getName()+" ");
                        System.out.print(bdata.get(i).getIsbn()+" ");
                        System.out.print(bdata.get(i).getBarcode()+" ");
                        System.out.println();
                    }


                    break;
                case 3:
                    check=0;
                    break;
            }

        } while (check == 1);

    }
}


