import java.util.ArrayList;

public interface studym {
    void viewlm(ArrayList<inst> idata, int idx);
    void addmaterial();
}
