public class content {
    private String con;
    content(String con){
        this.con=con;
    }
    public String getCon(){
        return con;
    }
}
