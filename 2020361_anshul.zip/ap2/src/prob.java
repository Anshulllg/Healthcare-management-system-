public class prob extends asse {

    private String ps;
    private int mm;
    private int aid;


    prob(String ps, int mm,int aid){
        this.ps=ps;
        this.mm=mm;
        this.aid=aid;

    }
    public String getPs(){
        return ps;
    }
    public int getMm(){
        return mm;
    }
    public int getAid(){
        return aid;
    }



}
