import java.util.Date;

public class slides {
    private String ts;
    private int ns;
    private Date date;

    slides(String ts, int ns , Date date){
        this.ts=ts;
        this.ns=ns;
        this.date=date;

    }
    public String getTs(){
        return ts;
    }
    public int getNs(){
        return ns;
    }
    public Date getDate(){
        return date;
    }

}
