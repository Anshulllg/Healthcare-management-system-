import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class vid {
    private String tv;
    private String nv;
    private Date date;

    vid(String tv, String nv, Date date){
        this.tv=tv;
        this.nv=nv;
        this.date=date;

    }
    public String getTv(){
        return tv;
    }
    public String getNv(){
        return nv;
    }
    public java.util.Date getDate() {
        return date;
    }
}
