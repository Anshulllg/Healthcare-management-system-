public class graded {
    private int aid;
    private int mm;
    private String name;
    private String sid;
    private String pid;
    private int ms;
    graded(int ms, String pid,String name){
        this.ms=ms;
        this.pid=pid;
        this.name=name;

    }

    public int getMs() {
        return ms;
    }

    public int getAid() {
        return aid;
    }
    public String getName(){
        return name;
    }
    public String getPid(){
        return pid;
    }
    public String getSid(){
        return sid;
    }
}
