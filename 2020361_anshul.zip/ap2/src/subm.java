public class subm {
    private int aid;
    private int mm;
    private String name;
    private String sid;
    private String pid;
    subm(int aid, String sid,String name){
        this.aid=aid;
        this.sid=sid;
        this.name=name;

    }

    public int getAid() {
        return aid;
    }
    public String getName(){
        return name;
    }
    public String getPid(){
        return pid;
    }
    public String getSid(){
        return sid;
    }

    public int getMm() {
        return mm;
    }
}
