import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static ArrayList<inst> idata=new ArrayList<>();
    public static ArrayList<stud> stdata=new ArrayList<>();


//    public static int mid= 0;
//    public static int assid=0;
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        inst I0=new inst("I0");
        idata.add(I0);
        inst I1=new inst("I1");
        idata.add(I1);
        stud S0=new stud("S0");
        stdata.add(S0);
        stud S1=new stud("S1");
        stdata.add(S1);
        stud S2=new stud("S2");
        stdata.add(S2);
//        inst a=new inst();

        int check = 1;
        do {
            System.out.println("Welcome to Backpack");
            System.out.println("1. Enter as instructor\n" + "2. Enter as student\n" + "3. Exit");

            int n = sc.nextInt();
            sc.nextLine();
            switch (n) {
                case 1:
                    System.out.println("Instructors:\n" + "0 - I0\n" + "1 - I1");
                    int ins=sc.nextInt();
                    System.out.println("Choose ID: "+ins);

                    if (ins==0){
                        System.out.println("Welcome I0");
                        I0.imenu(idata,stdata,0);
                    }
                    else if (ins==1){
                        System.out.println("Welcome I1");
                        I1.imenu(idata,stdata,1);
                    }
                    else{
                        System.out.println("Invalid input");
                    }

                    break;
                case 2:
                    System.out.println("Students:\n" + "0 - S0\n" + "1 - S1\n" + "2 - S2");
                    int stu=sc.nextInt();
                    System.out.println("Choose ID: "+stu);
                    if (stu==0){
                        System.out.println("Welcome S0");
                        S0.smenu(idata,stdata,0);

                    }
                    else if (stu==1){
                        System.out.println("Welcome S1");
                        S1.smenu(idata, stdata,1);
                    }
                    else if (stu==2){
                        System.out.println("Welcome S2");
                        S2.smenu(idata,stdata,1);
                    }
                    else{
                        System.out.println("Invalid input");
                    }

                    break;
                case 3:
                    check=0;
                    break;
            }

        } while (check == 1);

    }
}


