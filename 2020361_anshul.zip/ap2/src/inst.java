import java.util.ArrayList;
import java.util.Scanner;

public class inst{
    private String id;
    inst(String id){
        this.id=id;
    }

    public String getId() {
        return id;
    }

    void imenu(ArrayList<inst> idata, ArrayList<stud> stdata, int idx) {
        mat a=new mat();
        asse b=new asse();
        com c=new com();
        Scanner sc = new Scanner(System.in);



        int check = 1;
        do {
            System.out.println("INSTRUCTOR MENU\n" +
                    "1. Add class material\n" +
                    "2. Add assessments\n" +
                    "3. View lecture materials\n" +
                    "4. View assessments\n" +
                    "5. Grade assessments\n" +
                    "6. Close assessment\n" +
                    "7. View comments\n" +
                    "8. Add comments\n" +
                    "9. Logout\n");
            int n = sc.nextInt();
            sc.nextLine();
            switch (n) {
                case 1:
                    System.out.println("1. Add Lecture Slide\n" +
                            "2. Add Lecture Video");

                    a.addmaterial();
                    break;
                case 2:
                    System.out.println("1. Add Assignment\n" +
                            "2. Add Quiz");
                    b.addass();
                    break;
                case 3:
                    System.out.println("View lecture materials");
                    a.viewlm( idata,idx);
                    break;
                case 4:
                    System.out.println("View assesments");
                    b.viewass();
                    break;
                case 5:
                    System.out.println("Grade");
                    b.gradeass(idata.get(idx).getId());
                    break;
                case 6:
                    System.out.println("List of Open Assignments: ");

                    b.closeass();
                    break;
                case 7:
                    System.out.println("View comments");
                    c.viewcom();
                    break;
                case 8:
                    System.out.println("add comments");
                    c.addcom(idata.get(idx).getId());
                    break;
                case 9:
                    System.out.println("Logout");
                    check=0;
                    break;
            }
        } while (check == 1);
    }
}
