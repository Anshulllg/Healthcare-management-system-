public class quiz extends asse{
    private String pq;
    private int mq;
    private int aid;


    quiz(String pq, int mq, int aid){
        this.pq=pq;
        this.mq=mq;
        this.aid=aid;
    }
    public String getPq(){
        return pq;
    }
    public int getMq(){
        return mq;
    }
    public int getAid(){
        return aid;
    }
}
