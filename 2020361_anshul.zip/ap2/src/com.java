import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

class com {
    static public ArrayList<comments> cdata = new ArrayList<comments>();
    static Scanner sc=new Scanner(System.in);
    String comment;
    public void viewcom() {
        for(int i=0;i<cdata.size();i++){
            System.out.println("Comment "+i+": "+cdata.get(i).getComments()+" - "+cdata.get(i).getIdx());
            System.out.println(cdata.get(i).getDate());
            System.out.println(" ");
        }
    }

    public void addcom(String idd) {
        System.out.println("Enter comment: ");
        String comm=sc.nextLine();
        Date date = java.util.Calendar.getInstance().getTime();
        comments x=new comments(comm, date,idd);
        cdata.add(x);
    }

//    public void addcom(ArrayList<inst> idata,int idx) {
//        System.out.println("Enter comment: ");
//        String comm=sc.nextLine();
//        Date date = java.util.Calendar.getInstance().getTime();
//        comments x=new comments(comm, date,idx);
//        cdata.add(x);
//    }

}
