import java.util.ArrayList;
import java.util.Scanner;

class stud {
    private String id;
    stud(String id){
        this.id=id;
    }

    public String getId() {
        return id;
    }

    void smenu(ArrayList<inst> idata, ArrayList<stud> stdata, int idx) {
        mat a=new mat();
        asse b=new asse();
        com c=new com();
        Scanner sc = new Scanner(System.in);


//        int n = sc.nextInt();
        int check = 1;
        do {
            System.out.println("STUDENT MENU\n" +
                    "1. View lecture materials\n" +
                    "2. View assessments\n" +
                    "3. Submit assessment\n" +
                    "4. View grades\n" +
                    "5. View comments\n" +
                    "6. Add comments\n" +
                    "7. Logout");
            int n1 = sc.nextInt();
            switch (n1) {
                case 1:
                    System.out.println("View lecture material");
                    a.viewlm(idata,idx);
                    break;
                case 2:
                    System.out.println("View assesments");
                    b.viewass();
                    break;
                case 3:
                    System.out.println("Submit assessments");
                   b.submitass(stdata.get(idx).getId());
                    break;
                case 4:
                    System.out.println("Graded submissions");
                    b.grade();
                    break;
                case 5:
                    System.out.println("Comments");
                    c.viewcom();
                    break;
                case 6:
                    System.out.println("Enter comment:");
                    c.addcom(stdata.get(idx).getId());
                    break;
                case 7:
                    System.out.println("Logout");
                    check=0;
                    break;
            }
        } while (check == 1);
    }
}
