import java.util.ArrayList;

public interface Assessments {
    void gradeass(String pid);
    void submitass(String sid);
    void addass();
    void viewass();
    void closeass();
}
