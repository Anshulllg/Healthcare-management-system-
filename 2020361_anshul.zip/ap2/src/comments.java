import java.util.Date;

public class comments extends com{
    private String comments;
    private Date date;
    private String idx;

    comments(String comments, Date date, String idx){
        this.comments=comments;
        this.date=date;
        this.idx=idx;
    }
    public String getComments(){
        return comments;
    }

    public Date getDate() {
        return date;
    }
    public String getIdx(){
        return idx;
    }

}


