import java.util.ArrayList;
import java.util.Scanner;

class asse implements Assessments {
    int aid=0;
//    int close=0;
//    int submit;

//    static public ArrayList<asse> pdata = new ArrayList<asse>();
    static public ArrayList<subm> subdata = new ArrayList<subm>();
    static public ArrayList<graded> gdata = new ArrayList<graded>();

    static public ArrayList<prob> pdata = new ArrayList<prob>();
    static public ArrayList<Boolean> pdataopen=new ArrayList<Boolean>();
    static public ArrayList<Boolean> qdataopen=new ArrayList<Boolean>();
    static public ArrayList<quiz> qdata = new ArrayList<quiz>();
//    static public ArrayList<quiz> qdata = new ArrayList<quiz>();

    static Scanner sc=new Scanner(System.in);

    @Override
    public void gradeass(String pid){
        System.out.println("Lists of assessments");
        viewass();
        System.out.println("Enter ID of assessment to view submissions:");
        int asssid=sc.nextInt();
        System.out.println("Choose ID from these ungraded submissions");
        for(int i=0; i<subdata.size();i++){
            if(asssid==subdata.get(i).getAid()){
                System.out.println(i+". "+subdata.get(i).getSid());
            }
        }
        int cho=sc.nextInt();
        System.out.println("Submission:"+ subdata.get(cho).getName());
        System.out.println("------------------");
        System.out.println("Maximum Marks: "+subdata.get(cho).getMm());
        System.out.println("Marks scored: ");
        int ms=sc.nextInt();
        graded gg=new graded(ms,pid,subdata.get(cho).getName());
        gdata.add(gg);
    }
    public void grade(){
        for(int i=0; i<gdata.size();i++){
            System.out.println(gdata.get(i).getName());
        }

    }

    @Override
    public void submitass(String sid){

        System.out.println("Pending assessments");
        viewass();

        System.out.println("Enter id of the assessments: ");
        int assid=sc.nextInt();
        for(int i=0;i<pdata.size();i++){

            if(assid==pdata.get(i).getAid()){
                System.out.println("Enter filename of assignment: ");
                String fn=sc.nextLine();
                if(fn.endsWith(".zip") && !subdata.contains(assid)){
                    subm ss=new subm(assid,sid,fn);
                    subdata.add(ss);
                }else{
                    System.out.println("only .zip files are accepted or this assignment is already submitted" );
                }
            }
            else if(assid==qdata.get(i).getAid() && !subdata.contains(assid)){
                System.out.println(qdata.get(i).getPq());
                String ans=sc.nextLine();
                subm ss=new subm(assid,sid,ans);
                subdata.add(ss);
            }
        }

    }

    @Override
    public void addass() {
        aid++;

        int c1=sc.nextInt();
        sc.nextLine();
        if(c1==1){
            System.out.println("Enter problem statement:");
            String ps=sc.nextLine();
            sc.nextLine();
            System.out.println("Enter max marks:");
            int mm= sc.nextInt();
            prob x= new prob(ps, mm,aid);
            pdata.add(x);
            pdataopen.add(true);

        }else if(c1==2){
            System.out.println("Enter quiz question:");
            String pq=sc.nextLine();
            int mq=1;
            quiz y=new quiz(pq,mq,aid);
            qdata.add(y);
            qdataopen.add(true);
        }
    }

    @Override
    public void closeass(){
        for(int i=0; i<pdata.size();i++){
            if(pdataopen.get(i)){
                System.out.println(pdata.get(i).getPs()+"  "+pdata.get(i).getMm()+" "+pdata.get(i).getAid());
            }
        }
        for(int i=0; i<qdata.size();i++){
            if(qdataopen.get(i)){
                System.out.println(qdata.get(i).getPq()+"  "+qdata.get(i).getMq()+" "+qdata.get(i).getAid());
            }
        }
        System.out.println("Enter id of the assessment to close it: ");
        int iid=sc.nextInt();
        for(int i=0; i<pdata.size();i++){
            if(pdata.get(i).getAid()==iid){
                pdataopen.set(i,false);
            }
        }
        for(int i=0; i<qdata.size();i++){
            if(qdata.get(i).getAid()==iid){
                qdataopen.set(i,false);
            }
        }
    }

    @Override
    public void viewass() {
        for(int i=0; i<pdata.size();i++){
            System.out.println("ID: "+pdata.get(i).getAid()+" Assignment :"+ pdata.get(i).getPs()+" Maximum marks :"+ pdata.get(i).getMm());
//            System.out.println("Maximum marks :"+ pdata.get(i).getMm());
            System.out.println("--------------------");
        }
//        for(int i=0; i<pdata.size();i++){
//            System.out.println("ID: "+qdata.get(i).getAid()+" quiz :"+ qdata.get(i).getPq()+" Maximum marks : 1");
////            System.out.println("Maximum marks :"+ pdata.get(i).getMm());
//            System.out.println("--------------------");
//        }
    }
}
