import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

class mat implements studym {
    public static ArrayList<vid> vdata = new ArrayList<vid>();
    public static ArrayList<slides> sdata = new ArrayList<slides>();
    public static ArrayList<content> ccdata = new ArrayList<content>();
    static Scanner sc=new Scanner(System.in);

    public void viewlm( ArrayList<inst> idata, int idx) {
        System.out.println("Lecture materials");
        for(int i=0;i<sdata.size();i++){
            System.out.println("Title: "+sdata.get(i).getTs());
            for (int j=0;j<sdata.get(i).getNs();j++){
                System.out.println("Slide "+j+": "+ccdata.get(j).getCon());
            }
            Date date = java.util.Calendar.getInstance().getTime();
            System.out.println("Date of upload: "+date);
            System.out.println("Uploaded by: "+idata.get(idx).getId());
        }
        for(int i=0;i<vdata.size();i++){
            System.out.println("Title of video: "+vdata.get(i).getTv());
            System.out.println("Video file: "+vdata.get(i).getNv());
            Date date = java.util.Calendar.getInstance().getTime();
            System.out.println("Date of upload: "+date);
            System.out.println("Uploaded by: "+idata.get(idx).getId());
        }


    }

    @Override
    public void addmaterial() {

        int c1=sc.nextInt();
        sc.nextLine();
        if(c1==2){
            System.out.println("Enter topic of video:");
            String tv= sc.nextLine();
            System.out.println("Enter filename of video:");
            String nv= sc.nextLine();
            Date date = java.util.Calendar.getInstance().getTime();
            if(nv.endsWith(".mp4")) {
                vid x = new vid(tv, nv,date);
                vdata.add(x);
            } else {
                System.out.println( "Only .mp4 files are accepted. try again");

            }

        }
        else if(c1==1){
            System.out.println("Enter topic of slides:");
            String ts= sc.nextLine();
            System.out.println("Enter number of slides:");
            int ns= sc.nextInt();
            sc.nextLine();
            System.out.println("Enter content of slides");
            Date date = java.util.Calendar.getInstance().getTime();
            for(int i=0;i<ns;i++){
                System.out.println("Content of slide "+i+":");
                String con=sc.nextLine();
                content y=new content(con);
                ccdata.add(y);

            }
            slides x = new slides(ts, ns,date);
            sdata.add(x);
        }

    }
}


